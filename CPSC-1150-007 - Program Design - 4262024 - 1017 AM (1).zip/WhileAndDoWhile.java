public class WhileAndDoWhile
{
	public static void main(String[] args)
	{
		int number = -1, count = 0;
		
		while (number >= count)
		{
			System.out.print(count + " ");
			count++;
		}
		System.out.println();
		
		count = 0;
		do
		{
			System.out.print(count + " ");
			count++;
		}while (number >= count);
		System.out.println();
	}
}