import java.util.*;

public class WhileDemo
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		double next, average, sum = 0;
		int count = 1, numStud;

		System.out.println("Enter number of students.");
		numStud = input.nextInt();

		while (count <= numStud)
		{
			System.out.println("Enter nextscore:");
			next = input.nextDouble();
			sum = sum + next;
			count++;
		}

		if (numStud > 0)
		{
			average = sum / numStud;
			System.out.println("The average score: " + average);
		}
		else
			System.out.println("No scores to average.");

		System.out.println("End of program.");

	}
}