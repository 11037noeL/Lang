import java.util.Scanner;

public class PrintCalendar2
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		int year, month;

		System.out.println("\nThis programs displays a month calendar.\n");
      
		do
		{
			System.out.print("Please enter a year: ");
			year = in.nextInt();
         
			System.out.print("Please enter a month: ");
			month = in.nextInt();
		} while ( !verifyInput(year, month));
      
		printMonth(year, month);
	}
   
	public static boolean verifyInput(int year, int month)
	{
		boolean flag = true;
		if (year < 1000 || year > 4000)
		{
			System.out.println("Error: Year must be between 1000 and 4000.");
			flag = false;
		}
      
		if (month < 1 || month > 12)
		{
			System.out.println("Error: Month mube 1 - 12");
			flag = false;
		}
      
		return flag;
	}
   
	public static void printMonth(int year, int month)
	{
		printMonthTitle(year, month);
		printMonthBody(year, month);
	}
   
	public static void printMonthTitle(int year, int month)
	{
		System.out.println("\t\t" + monthName(month) + "  " + year);
		System.out.println("-------------------------------------------"
				+ "\nSun Mon Tue Wed Thu Fri Sat");
	}
   
	public static void printMonthBody(int year, int month)
	{
      
	}
   
	public static String monthName(int month)
	{
		switch (month)
		{
			case 1:
				return "January";
			case 2:
				return "February";
			case 3:
				return "March";
			case 4:
				return "April";
			case 5:
				return "May";
			case 6:
				return "June";
			case 7:
				return "July";
			case 8:
				return "August";
			case 9:
				return "September";
			case 10:
				return "October";
			case 11:
				return "November";
			default:
				return "December";
         
		}
	}
}