import java.util.Scanner;

public class PrintCalendar1
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		int year, month;

		System.out.println("\nThis programs displays a month calendar.\n");
      
		do
		{
			System.out.print("Please enter a year: ");
			year = in.nextInt();
         
			System.out.print("Please enter a month: ");
			month = in.nextInt();
		} while ( !verifyInput(year, month));
      
		printMonth(year, month);
	}
   
	public static boolean verifyInput(int year, int month)
	{
		return false;
	}
   
	public static void printMonth(int year, int month)
	{
		System.out.println("In printMonth method.....");
	}
}