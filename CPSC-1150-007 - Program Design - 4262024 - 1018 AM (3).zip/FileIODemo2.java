import java.io.*;
import java.util.*;

public class FileIODemo2
{
   public static void main(String[] args) throws IOException
   {
      
      PrintWriter outFile;
      String line, inFileName, outFileName;
      Scanner keyboard = new Scanner (System.in);
      
      inFileName = readFileName(keyboard, "Please enter the input File name: ");
      outFileName = readFileName(keyboard, "Please enter the output File name: ");
      
      inFile = openInFile(inFileName);
      outFile = openOutFile(outFileName);
      
      while (inFile.hasNextLine())
      {
         line = inFile.nextLine();
      
         System.out.println(line);
         outFile.println(line);
      }
      
      inFile.close();
      outFile.close();
      
   }
   
   public static String readFileName(Scanner scan, String msg)
   {
      String name; 
      System.out.println(msg);
      name = scan.nextLine();
      return name;
   }
   
   public static Scanner openInFile(String name) throws IOException
   {
      Scanner in = new Scanner(new File(name));
      return in;
   }
   
   public static PrintWriter openOutFile(String name) throws IOException
   {
      PrintWriter out = new PrintWriter(new FileWriter(name));
      return out;
   }
}