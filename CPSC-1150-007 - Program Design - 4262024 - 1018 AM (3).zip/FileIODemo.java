import java.io.*;
import java.util.*;

public class FileIODemo
{
	public static void main(String[] args) throws IOException
	{
		Scanner inFile;
		PrintWriter outFile;
		String line, inFileName, outFileName;
		Scanner keyboard = new Scanner (System.in);
      
		System.out.println("Please enter the input File name: ");
		inFileName = keyboard.nextLine();
      
		System.out.println("Please enter the output File name: ");
		outFileName = keyboard.nextLine();
      
		inFile = new Scanner(new File(inFileName));
		outFile = new PrintWriter(new File(outFileName));
      
		while (inFile.hasNextLine())
		{
			line = inFile.nextLine();
      
			System.out.println(line);
			outFile.println(line);
		}
      
		inFile.close();
		outFile.close();
      
	}
}