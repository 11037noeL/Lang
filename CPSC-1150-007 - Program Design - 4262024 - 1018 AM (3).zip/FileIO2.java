import java.io.*;
import java.util.*;

public class FileIO2
{
	public static void main(String[] args) throws IOException
	{
		Scanner inFile;
		PrintWriter outFile;
		String line;
      
		inFile = new Scanner(new File("input.txt"));
		outFile = new PrintWriter(new File("output2.txt"));
      
		while (inFile.hasNextLine())
		{
			line = inFile.nextLine();
      
			System.out.println(line);
			outFile.println(line);
		}
      
		inFile.close();
		outFile.close();
      
	}
}