
//#### Class Activity sol ###

public class ArraySum {
    public static void main(String[] args) {
        
	// Declare an array of double values named "numbers" with a size of 5
        double[] numbers = new double[5];

        // Initialize the array with some random double values
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = Math.random() * 100; // Generates random double values between 0.0 (inclusive) and 100.0 (exclusive)
        }

        // Print all the elements of the array using a loop
        System.out.println("Elements of the array:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i]);
        }

        // Calculate and print the sum of all elements in the array
        double sum = 0;
        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i];
        }
        System.out.println("Sum of all elements: " + sum);
    }
}

