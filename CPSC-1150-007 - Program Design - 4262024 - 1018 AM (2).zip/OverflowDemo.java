public class OverflowDemo
{
	public static void main(String[] args)
	{
		int data = 500000;
      
		for (int i = 0; i < 4; i++)
		{
			data *= 1000;
			System.out.println("The content of data is: " + data);
		}
	}
}