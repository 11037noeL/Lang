public class OverflowDemo3
{
	public static void main(String[] args)
	{
      
		byte number = 98;
		int data = 200;
      
		System.out.println(" data = " + data + " number = " + number);
      
		number = (byte) data;
      
		System.out.println(" data = " + data + " number = " + number);
      
	}
}