public class OverflowDemo2
{
	public static void main(String[] args)
	{
      
		byte number = 98;
		int data = 125938;
      
		System.out.println(" data = " + data + " number = " + number);
      
		number = (byte) data;
      
		System.out.println(" data = " + data + " number = " + number);
      
	}
}