
//#### demonstartion Array Use ###

public class DemonstrationActivity {
    public static void main(String[] args) {
        
        int[] myList = new int[10]; // Example array declaration and initialization
        int length = myList.length; // Getting the length of the array
        System.out.println("Length of the array: " + length);
        
        System.out.println("The first element value is: " + myList[0]);
        
    }
}

