import java.util.Scanner;

public class ClassifyScores {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] scores = new int[10];
        int inputNum = userInput(input);

        while (inputNum >= 0) {
            if (inputNum > 100)
                System.out.println("Invalid number!");
            else
                updateScore(scores, inputNum);
            inputNum = userInput(input);
        }

        displayResults(scores);
    }

    public static int userInput(Scanner input) {
        System.out.println("Input a number between 0 and 100 both inclusive and enter a negative number to terminate");
        return input.nextInt();
    }

    public static void updateScore(int[] scores, int num) {
        if (num == 100)
            scores[9]++;
        else
            scores[num / 10]++;
    }

    public static void displayResults(int[] scores) {
        // Print table headers
        System.out.printf("%-15s %-15s\n", "Range", "Number of scores");
        System.out.printf("%-15s %-15s\n", "-----", "----------------");

        // Print data rows
        for (int i = 0; i < scores.length; i++) {
            if (i == scores.length - 1)
                System.out.printf("%-15s %-15d\n", 90 + "-" + 100, scores[i]);
            else
                System.out.printf("%-15s %-15d\n", (i * 10) + "-" + (i * 10 + 9), scores[i]);
        }
    }
}